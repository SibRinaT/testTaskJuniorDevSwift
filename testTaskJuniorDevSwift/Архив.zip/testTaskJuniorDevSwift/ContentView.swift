//
//  ContentView.swift
//  testTaskJuniorDevSwift
//
//  Created by Ainur on 19.12.2023.
//

import SwiftUI

struct ContentView: View {
  
    var body: some View {
        VStack {
            Text("Splash is done!")
                .font(.title)
        }
    }
}

#Preview {
    ContentView()
}
