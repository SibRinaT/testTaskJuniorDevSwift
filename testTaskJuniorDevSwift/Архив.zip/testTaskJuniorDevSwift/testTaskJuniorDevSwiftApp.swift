//
//  testTaskJuniorDevSwiftApp.swift
//  testTaskJuniorDevSwift
//
//  Created by Ainur on 19.12.2023.
//

import SwiftUI

@main
struct testTaskJuniorDevSwiftApp: App {
    var body: some Scene {
        WindowGroup {
            SplashView()
        }
    }
}
